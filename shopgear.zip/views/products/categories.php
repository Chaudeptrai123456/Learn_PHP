<?php
// Mảng dữ liệu mẫu đồng bộ 100% theo cấu trúc bạn cung cấp
function formatPrice($n) { 
    return number_format($n, 0, ',', '.') . ' ₫'; 
}

?>
<style>
:root {
    --cat-primary: #0071e3;
    --cat-dark: #1d1d1f;
    --cat-light-gray: #f5f5f7;
    --cat-border: #e5e5e7;
    --cat-text-gray: #86868b;
    --cat-transition: all 0.4s cubic-bezier(0.25, 0.1, 0.25, 1);
}

.catalog-wrapper {
    padding-top: 70px;
    background-color: #ffffff;
}

/* --- CATALOG HEADER BANNER --- */
.catalog-header {
    background-color: var(--cat-light-gray);
    padding: 40px 0;
    text-align: center;
    border-bottom: 1px solid var(--cat-border);
}

.catalog-header h1 {
    font-size: 2rem;
    font-weight: 700;
    color: var(--cat-dark);
    margin-bottom: 15px;
    letter-spacing: -0.5px;
}

.catalog-search-box {
    max-width: 500px;
    margin: 0 auto;
    position: relative;
}

.catalog-search-box input {
    width: 100%;
    padding: 12px 20px 12px 45px;
    font-family: inherit;
    font-size: 0.95rem;
    border: 1px solid var(--cat-border);
    border-radius: 12px;
    outline: none;
    background-color: #ffffff;
    transition: var(--cat-transition);
}

.catalog-search-box input:focus {
    border-color: var(--cat-primary);
    box-shadow: 0 0 0 4px rgba(0, 113, 227, 0.12);
}

.catalog-search-box i {
    position: absolute;
    left: 18px;
    top: 50%;
    transform: translateY(-50%);
    color: var(--cat-text-gray);
}

/* --- BỐ CỤC CHÍNH (GRID LAYOUT) --- */
.catalog-main-layout {
    display: grid;
    grid-template-columns: 280px 1fr;
    /* Cột bên trái 280px, bên phải chiếm hết phần còn lại */
    gap: 40px;
    padding: 40px 0 100px;
    align-items: start;
}

/* --- CỘT LỌC BÊN TRÁI CỐ ĐỊNH (STICKY SIDEBAR) --- */
.filter-sidebar {
    position: sticky;
    top: 90px;
    /* Ghim cách Header fixed một khoảng thở (70px chiều cao header + 20px) */
    max-height: calc(100vh - 110px);
    /* Đảm bảo không vượt quá chiều cao màn hình */
    overflow-y: auto;
    /* Cho phép tự cuộn nội bộ nếu danh sách bộ lọc quá dài */
    background-color: #ffffff;
    border-right: 1px solid var(--cat-border);
    padding-right: 25px;
}

/* Ẩn thanh cuộn của trình duyệt trong sidebar hỗ trợ thẩm mỹ */
.filter-sidebar::-webkit-scrollbar {
    width: 4px;
}

.filter-sidebar::-webkit-scrollbar-thumb {
    background-color: var(--cat-border);
    border-radius: 4px;
}

.filter-group {
    margin-bottom: 30px;
}

.filter-group h4 {
    font-size: 0.85rem;
    font-weight: 700;
    text-transform: uppercase;
    color: var(--cat-text-gray);
    margin-bottom: 16px;
    letter-spacing: 0.5px;
}

.filter-options-list {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.filter-label {
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 0.9rem;
    font-weight: 500;
    color: var(--cat-dark);
    cursor: pointer;
    user-select: none;
    transition: var(--cat-transition);
}

.filter-label:hover {
    color: var(--cat-primary);
}

.filter-label input {
    accent-color: var(--cat-primary);
    width: 16px;
    height: 16px;
    cursor: pointer;
}

.btn-clear-filters {
    width: 100%;
    padding: 12px;
    background-color: var(--cat-light-gray);
    border: 1px solid transparent;
    border-radius: 10px;
    font-family: inherit;
    font-size: 0.85rem;
    font-weight: 700;
    color: var(--cat-dark);
    cursor: pointer;
    transition: var(--cat-transition);
    margin-top: 10px;
}

.btn-clear-filters:hover {
    background-color: var(--cat-border);
}

/* --- NỘI DUNG SẢN PHẨM BÊN PHẢI --- */
.catalog-content-right {
    display: flex;
    flex-direction: column;
    gap: 20px;
}

/* Thanh toolbar tinh gọn của sản phẩm */
.catalog-toolbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-bottom: 15px;
    border-bottom: 1px solid var(--cat-border);
}

.results-count {
    font-size: 0.9rem;
    color: var(--cat-text-gray);
    font-weight: 600;
}

.sort-select {
    padding: 10px 14px;
    font-family: inherit;
    font-size: 0.85rem;
    font-weight: 600;
    color: var(--cat-dark);
    background-color: var(--cat-light-gray);
    border: 1px solid transparent;
    border-radius: 10px;
    outline: none;
    cursor: pointer;
    transition: var(--cat-transition);
}

.sort-select:hover {
    background-color: var(--cat-border);
}

/* Lưới sản phẩm */
.catalog-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(290px, 1fr));
    gap: 24px;
}

/* --- PREMIUM PRODUCT CARD --- */
.catalog-card {
    background: #fff;
    border-radius: 20px;
    padding: 20px;
    border: 1px solid var(--cat-border);
    transition: var(--cat-transition);
    display: flex;
    flex-direction: column;
    position: relative;
    overflow: hidden;
}

.catalog-card:hover {
    border-color: var(--cat-primary);
    box-shadow: 0 12px 30px rgba(0, 0, 0, 0.04);
    transform: translateY(-4px);
}

.catalog-card-img-wrapper {
    width: 100%;
    height: 200px;
    display: flex;
    align-items: center;
    justify-content: center;
    position: relative;
    overflow: hidden;
    border-radius: 12px;
    margin-bottom: 16px;
    background-color: #ffffff;
}

.catalog-card-img {
    max-width: 100%;
    max-height: 100%;
    object-fit: contain;
    transition: var(--cat-transition);
}

.catalog-card:hover .catalog-card-img {
    transform: scale(1.04);
}

.catalog-card-badge {
    position: absolute;
    top: 15px;
    left: 15px;
    background: var(--cat-dark);
    color: #fff;
    font-size: 9px;
    padding: 3px 8px;
    border-radius: 5px;
    font-weight: 700;
    z-index: 5;
}

.catalog-card-brand {
    font-size: 0.75rem;
    font-weight: 700;
    color: var(--cat-primary);
    text-transform: uppercase;
    margin-bottom: 4px;
    letter-spacing: 0.5px;
}

.catalog-card-name {
    font-weight: 700;
    font-size: 1.05rem;
    color: var(--cat-dark);
    margin-bottom: 6px;
    min-height: 22px;
    line-height: 1.4;
}

.catalog-card-desc {
    font-size: 0.8rem;
    color: var(--cat-text-gray);
    line-height: 1.5;
    margin-bottom: 12px;
    min-height: 36px;
}

.catalog-card-specs {
    list-style: none;
    padding-top: 10px;
    border-top: 1px dashed var(--cat-border);
    margin-bottom: 15px;
    display: flex;
    flex-direction: column;
    gap: 5px;
}

.catalog-card-specs li {
    font-size: 0.75rem;
    color: var(--cat-dark);
    font-weight: 500;
}

.catalog-card-specs li span {
    color: var(--cat-text-gray);
    font-weight: 400;
}

.catalog-card-price-row {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 12px;
}

.catalog-card-price-new {
    font-weight: 800;
    font-size: 1.15rem;
    color: var(--cat-primary);
}

.catalog-card-price-old {
    text-decoration: line-through;
    color: var(--cat-text-gray);
    font-size: 0.85rem;
}

.catalog-stock-row {
    margin-bottom: 15px;
}

.catalog-stock-info {
    display: flex;
    justify-content: space-between;
    font-size: 0.7rem;
    font-weight: 700;
    color: var(--cat-dark);
    margin-bottom: 6px;
}

.catalog-stock-bar {
    height: 5px;
    background-color: var(--cat-light-gray);
    border-radius: 10px;
    overflow: hidden;
}

.catalog-stock-fill {
    height: 100%;
    background: linear-gradient(90deg, var(--cat-primary), #5ac8fa);
    border-radius: 10px;
    transition: width 0.5s ease-in-out;
}

.btn-catalog-add {
    width: 100%;
    padding: 12px;
    border-radius: 10px;
    border: none;
    background: var(--cat-dark);
    color: #fff;
    font-weight: 700;
    cursor: pointer;
    transition: var(--cat-transition);
    text-align: center;
    text-decoration: none;
    font-size: 0.85rem;
}

.btn-catalog-add:hover {
    background: var(--cat-primary);
}

.no-results {
    grid-column: 1 / -1;
    text-align: center;
    padding: 80px 20px;
}

.no-results i {
    font-size: 3rem;
    color: var(--cat-text-gray);
    margin-bottom: 15px;
}

.no-results p {
    font-size: 1.1rem;
    color: var(--cat-dark);
    font-weight: 600;
}

/* --- RESPONSIVE CHO TABLET VÀ MOBILE --- */
@media (max-width: 992px) {
    .catalog-main-layout {
        grid-template-columns: 1fr;
        /* Trở về 1 cột trên giao diện hẹp */
        gap: 30px;
    }

    .filter-sidebar {
        position: static;
        /* Hủy cơ chế ghim cố định */
        max-height: none;
        border-right: none;
        border-bottom: 1px solid var(--cat-border);
        padding-right: 0;
        padding-bottom: 25px;
    }

    .filter-panel-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 20px;
    }
}
</style>

<div class="catalog-wrapper">
    <!-- Banner tiêu đề đã được ẩn đi để đồng bộ theo thiết kế -->
    <div class="container">
        <!-- Bố cục 2 cột chính -->
        <div class="catalog-main-layout">

            <!-- CỘT LỌC BÊN TRÁI (STICKY SIDEBAR) -->
            <aside class="filter-sidebar">

                <!-- Nhóm lọc: Danh mục (Đồng bộ với dữ liệu Mock mới) -->
                <div class="filter-group">
                    <h4>Danh mục</h4>
                    <div class="filter-options-list">
                        <label class="filter-label">
                            <input type="radio" name="filterCat" value="all" checked onchange="applyFilters()">
                            <span>Tất cả</span>
                        </label>
                        <label class="filter-label">
                            <input type="radio" name="filterCat" value="phone" onchange="applyFilters()">
                            <span>Điện thoại</span>
                        </label>
                        <label class="filter-label">
                            <input type="radio" name="filterCat" value="laptop" onchange="applyFilters()">
                            <span>Máy tính / Laptop</span>
                        </label>
                        <label class="filter-label">
                            <input type="radio" name="filterCat" value="tablet" onchange="applyFilters()">
                            <span>Máy tính bảng / iPad</span>
                        </label>
                        <label class="filter-label">
                            <input type="radio" name="filterCat" value="accessory" onchange="applyFilters()">
                            <span>Phụ kiện / Đồng hồ / Tai nghe</span>
                        </label>
                    </div>
                </div>

                <!-- Nhóm lọc: Thương hiệu (Đồng bộ với dữ liệu Mock mới) -->
                <div class="filter-group">
                    <h4>Thương hiệu</h4>
                    <div class="filter-options-list">
                        <label class="filter-label">
                            <input type="radio" name="filterBrand" value="all" checked onchange="applyFilters()">
                            <span>Tất cả hãng</span>
                        </label>
                        <label class="filter-label">
                            <input type="radio" name="filterBrand" value="Apple Store Official"
                                onchange="applyFilters()">
                            <span>Apple</span>
                        </label>
                        <label class="filter-label">
                            <input type="radio" name="filterBrand" value="Samsung Official" onchange="applyFilters()">
                            <span>Samsung</span>
                        </label>
                        <label class="filter-label">
                            <input type="radio" name="filterBrand" value="Dell Official" onchange="applyFilters()">
                            <span>Dell</span>
                        </label>
                        <label class="filter-label">
                            <input type="radio" name="filterBrand" value="Asus Official" onchange="applyFilters()">
                            <span>Asus</span>
                        </label>
                        <label class="filter-label">
                            <input type="radio" name="filterBrand" value="Sony Official" onchange="applyFilters()">
                            <span>Sony</span>
                        </label>
                    </div>
                </div>

                <!-- Nhóm lọc: Khoảng giá -->
                <div class="filter-group">
                    <h4>Khoảng giá</h4>
                    <div class="filter-options-list">
                        <label class="filter-label">
                            <input type="radio" name="filterPrice" value="all" checked onchange="applyFilters()">
                            <span>Mọi mức giá</span>
                        </label>
                        <label class="filter-label">
                            <input type="radio" name="filterPrice" value="under10" onchange="applyFilters()">
                            <span>Dưới 10 triệu</span>
                        </label>
                        <label class="filter-label">
                            <input type="radio" name="filterPrice" value="10to30" onchange="applyFilters()">
                            <span>10 triệu - 30 triệu</span>
                        </label>
                        <label class="filter-label">
                            <input type="radio" name="filterPrice" value="over30" onchange="applyFilters()">
                            <span>Trên 30 triệu</span>
                        </label>
                    </div>
                </div>

                <!-- Nút đặt lại nhanh -->
                <button class="btn-clear-filters" onclick="clearAllFilters()">Đặt lại bộ lọc</button>

            </aside>

            <!-- CỘT NỘI DUNG SẢN PHẨM BÊN PHẢI -->
            <section class="catalog-content-right">

                <!-- Thanh công cụ nhỏ điều phối -->
                <div class="catalog-toolbar">
                    <span class="results-count">
                        Danh sách: <span id="resultsCount"><?php echo count($products); ?></span> sản phẩm
                    </span>

                    <!-- Menu sắp xếp -->
                    <select id="sortOption" class="sort-select" onchange="applyFilters()">
                        <option value="default">Sắp xếp</option>
                        <option value="priceAsc">Giá thấp đến cao</option>
                        <option value="priceDesc">Giá cao đến thấp</option>
                        <option value="nameAsc">Tên sản phẩm (A-Z)</option>
                    </select>
                </div>

                <!-- Grid hiển thị danh sách sản phẩm -->
                <div class="catalog-grid" id="catalogGrid">
                    <?php foreach($products as $p): 
                        $percent = ($p['stock'] > 0) ? ($p['sold'] / $p['stock']) * 100 : 0;
                    ?>
                    <div class="catalog-card" data-id="<?php echo $p['id']; ?>" data-cat="<?php echo $p['cat']; ?>"
                        data-brand="<?php echo $p['brand']; ?>" data-price="<?php echo $p['price']; ?>"
                        data-name="<?php echo strtolower($p['name']); ?>">

                        <span class="catalog-card-badge"><?php echo $p['badge']; ?></span>

                        <div class="catalog-card-img-wrapper">
                            <img src="<?php echo $p['image']; ?>" alt="<?php echo $p['name']; ?>"
                                class="catalog-card-img" <?php if (isset($p['images'][1])): ?>
                                onmouseover="this.src='<?php echo $p['images'][1]; ?>'"
                                onmouseout="this.src='<?php echo $p['image']; ?>'" <?php endif; ?>>
                        </div>

                        <div class="catalog-card-brand"><?php echo $p['brand']; ?></div>
                        <h3 class="catalog-card-name"><?php echo $p['name']; ?></h3>
                        <p class="catalog-card-desc"><?php echo $p['short_desc']; ?></p>

                        <!-- KHU VỰC SỬA LỖI TRƯỜNG SPEC KHÔNG ĐỒNG BỘ: Sử dụng vòng lặp tự động lấy 3 thông số đầu tiên -->
                        <ul class="catalog-card-specs">
                            <?php 
                            $count = 0;
                            if (isset($p['specs']) && is_array($p['specs'])) {
                                foreach($p['specs'] as $key => $value) {
                                    if ($count >= 3) break; // Chỉ lấy tối đa 3 thông số đầu tiên cho cân đối giao diện
                                    echo '<li><span>' . htmlspecialchars($key) . ':</span> ' . htmlspecialchars($value) . '</li>';
                                    $count++;
                                }
                            }
                            ?>
                        </ul>

                        <div class="catalog-card-price-row">
                            <span class="catalog-card-price-new"><?php echo formatPrice($p['price']); ?></span>
                            <span class="catalog-card-price-old"><?php echo formatPrice($p['old_price']); ?></span>
                        </div>

                        <div class="catalog-stock-row">
                            <div class="catalog-stock-info">
                                <span>Đã bán: <?php echo $p['sold']; ?></span>
                                <span>Còn lại: <?php echo ($p['stock'] - $p['sold']); ?></span>
                            </div>
                            <div class="catalog-stock-bar">
                                <div class="catalog-stock-fill" style="width: <?php echo $percent; ?>%;"></div>
                            </div>
                        </div>

                        <a href="/assignment/product/<?php echo $p['slug']; ?>" class="btn-catalog-add">Thêm vào giỏ
                            hàng</a>
                    </div>
                    <?php endforeach; ?>
                </div>

            </section>

        </div>
    </div>
</div>

<!-- JavaScript xử lý bộ lọc động trên client-side -->
<script>
// Logic Lọc và Sắp xếp đồng bộ
function applyFilters() {
    const grid = document.getElementById('catalogGrid');
    const cards = Array.from(grid.getElementsByClassName('catalog-card'));

    // Đọc từ khóa tìm kiếm nhanh từ ô tìm kiếm Header (id="searchInput")
    const searchInput = document.getElementById('searchInput');
    const searchVal = searchInput ? searchInput.value.toLowerCase().trim() : '';

    // Đọc trạng thái lọc từ Sidebar trái
    const catVal = document.querySelector('input[name="filterCat"]:checked').value;
    const brandVal = document.querySelector('input[name="filterBrand"]:checked').value;
    const priceVal = document.querySelector('input[name="filterPrice"]:checked').value;

    // Đọc lựa chọn sắp xếp
    const sortVal = document.getElementById('sortOption').value;

    let visibleCount = 0;

    cards.forEach(card => {
        const name = card.getAttribute('data-name');
        const cat = card.getAttribute('data-cat');
        const brand = card.getAttribute('data-brand');
        const price = parseInt(card.getAttribute('data-price'));

        const matchesSearch = name.includes(searchVal);
        const matchesCat = (catVal === 'all' || cat === catVal);
        const matchesBrand = (brandVal === 'all' || brand === brandVal);

        let matchesPrice = true;
        if (priceVal === 'under10') {
            matchesPrice = (price < 10000000);
        } else if (priceVal === '10to30') {
            matchesPrice = (price >= 10000000 && price <= 30000000);
        } else if (priceVal === 'over30') {
            matchesPrice = (price > 30000000);
        }

        if (matchesSearch && matchesCat && matchesBrand && matchesPrice) {
            card.style.display = 'flex';
            visibleCount++;
        } else {
            card.style.display = 'none';
        }
    });

    // Cập nhật thống kê kết quả tìm thấy
    document.getElementById('resultsCount').innerText = visibleCount;

    // Hiển thị thông báo khi bộ lọc không trả về kết quả nào
    let noResultMsg = document.getElementById('noResultsMsg');
    if (visibleCount === 0) {
        if (!noResultMsg) {
            noResultMsg = document.createElement('div');
            noResultMsg.id = 'noResultsMsg';
            noResultMsg.className = 'no-results';
            noResultMsg.innerHTML =
                '<i class="fas fa-box-open"></i><p>Không có sản phẩm nào phù hợp bộ lọc hiện tại.</p>';
            grid.appendChild(noResultMsg);
        }
    } else {
        if (noResultMsg) noResultMsg.remove();
    }

    // Logic sắp xếp thứ tự
    if (sortVal !== 'default') {
        cards.sort((a, b) => {
            if (sortVal === 'priceAsc') {
                return parseInt(a.getAttribute('data-price')) - parseInt(b.getAttribute('data-price'));
            } else if (sortVal === 'priceDesc') {
                return parseInt(b.getAttribute('data-price')) - parseInt(a.getAttribute('data-price'));
            } else if (sortVal === 'nameAsc') {
                return a.getAttribute('data-name').localeCompare(b.getAttribute('data-name'));
            }
        });

        cards.forEach(card => {
            if (card.style.display !== 'none') {
                grid.appendChild(card);
            }
        });
    }
}

// Hàm đặt lại toàn bộ thiết lập lọc về ban đầu
function clearAllFilters() {
    document.querySelector('input[name="filterCat"][value="all"]').checked = true;
    document.querySelector('input[name="filterBrand"][value="all"]').checked = true;
    document.querySelector('input[name="filterPrice"][value="all"]').checked = true;

    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.value = '';
    }

    document.getElementById('sortOption').value = 'default';

    applyFilters();
}

// Lắng nghe sự kiện từ ô tìm kiếm chính trên Header
document.addEventListener('DOMContentLoaded', () => {
    const headerSearch = document.getElementById('searchInput');
    if (headerSearch) {
        headerSearch.addEventListener('input', applyFilters);
    }
    // Chạy bộ lọc lần đầu để đảm bảo đồng bộ
    applyFilters();
});
</script>